/**
 * 
 */
package it.unicam.cs.asdl2324.mp2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;


// ATTENZIONE: è vietato includere import a pacchetti che non siano della Java SE

/**
 * Classe che implementa un grafo non orientato tramite matrice di adiacenza.
 * Non sono accettate etichette dei nodi null e non sono accettate etichette
 * duplicate nei nodi (che in quel caso sono lo stesso nodo).
 * 
 * I nodi sono indicizzati da 0 a nodeCoount() - 1 seguendo l'ordine del loro
 * inserimento (0 è l'indice del primo nodo inserito, 1 del secondo e così via)
 * e quindi in ogni istante la matrice di adiacenza ha dimensione nodeCount() *
 * nodeCount(). La matrice, sempre quadrata, deve quindi aumentare di dimensione
 * ad ogni inserimento di un nodo. Per questo non è rappresentata tramite array
 * ma tramite ArrayList.
 * 
 * Gli oggetti GraphNode<L>, cioè i nodi, sono memorizzati in una mappa che
 * associa ad ogni nodo l'indice assegnato in fase di inserimento. Il dominio
 * della mappa rappresenta quindi l'insieme dei nodi.
 * 
 * Gli archi sono memorizzati nella matrice di adiacenza. A differenza della
 * rappresentazione standard con matrice di adiacenza, la posizione i,j della
 * matrice non contiene un flag di presenza, ma è null se i nodi i e j non sono
 * collegati da un arco e contiene un oggetto della classe GraphEdge<L> se lo
 * sono. Tale oggetto rappresenta l'arco. Un oggetto uguale (secondo equals) e
 * con lo stesso peso (se gli archi sono pesati) deve essere presente nella
 * posizione j, i della matrice.
 * 
 * Questa classe non supporta i metodi di cancellazione di nodi e archi, ma
 * supporta tutti i metodi che usano indici, utilizzando l'indice assegnato a
 * ogni nodo in fase di inserimento.
 * 
 * @author Luca Tesei (template) Tommaso, Cosci, tommaso.cosci@studenti.unicam.it (implementazione)
 *
 * 
 */
public class AdjacencyMatrixUndirectedGraph<L> extends Graph<L> {
    /*
     * Le seguenti variabili istanza sono protected al solo scopo di agevolare
     * il JUnit testing
     */
	
	private int currentIndex=0; //per tenere traccia degli indici utilizzati

    /*
     * Insieme dei nodi e associazione di ogni nodo con il proprio indice nella
     * matrice di adiacenza
     */
    protected Map<GraphNode<L>, Integer> nodesIndex;

    /*
     * Matrice di adiacenza, gli elementi sono null o oggetti della classe
     * GraphEdge<L>. L'uso di ArrayList permette alla matrice di aumentare di
     * dimensione gradualmente ad ogni inserimento di un nuovo nodo e di
     * ridimensionarsi se un nodo viene cancellato.
     */
    protected ArrayList<ArrayList<GraphEdge<L>>> matrix;

    /**
     * Crea un grafo vuoto.
     */
    public AdjacencyMatrixUndirectedGraph() {
        this.matrix = new ArrayList<ArrayList<GraphEdge<L>>>();
        this.nodesIndex = new HashMap<GraphNode<L>, Integer>();
    }

    @Override
    public int nodeCount() {
    	return this.nodesIndex.size(); //ritorno la size della mappa poiché ad ogni indice corrisponde un nodo
    }

    @Override
    public int edgeCount() {
        int count=0;
        HashSet<Object> visitedElements = new HashSet<>();//istanzio un set per memorizzare gli elementi già visitati

        for (ArrayList<GraphEdge<L>> array : matrix) { //scorro tutta la matrice (righe e colonne)
            for (GraphEdge<L> elemento : array) {
                if (elemento != null && !visitedElements.contains(elemento)) { //se non è nullo e non l'ho già visitato
                    visitedElements.add(elemento); 
                    count++; //aggiorno il contatore 
                }
            }
        }
        return count;
    }
    
    @Override
    public void clear() { 
        this.nodesIndex = new HashMap<GraphNode<L>, Integer>(); // ricreo sia la mappa sia la matrice vuote
        this.matrix = new ArrayList<ArrayList<GraphEdge<L>>>();
    }

    @Override
    public boolean isDirected() {
    	return false; //ritorno falso poiché stiamo implementando un grafo non orientato
    }

    /*
     * Gli indici dei nodi vanno assegnati nell'ordine di inserimento a partire
     * da zero
     */
    @Override
    public boolean addNode(GraphNode<L> node) {
    	if(node==null) //controllo il passaggio di elementi nulli
    		throw new NullPointerException("Il nodo passato è nullo");
    	
    	if(nodesIndex.containsKey(node)) //controllo se il nodo è già presente
    		return false;
    	
		nodesIndex.put(node, currentIndex); //aggiungo alla mappa il nodo
		currentIndex++; //aggiorno l'indice
		
		ArrayList<GraphEdge<L>> newRow = new ArrayList<GraphEdge<L>>(); //nuova riga per il nodo aggiunto
		for (int i = 0; i < matrix.size(); i++) { //metto null nella newRow per un num di elementi lunghi 
	        newRow.add(null);						//quanto la lunghezza della matrice
	    }
	    
		matrix.add(newRow); //aggiungo la newRow alla matrice
		
	    
	    for (ArrayList<GraphEdge<L>> row : matrix) { // aggiungo una nuova colonna per il nuovo nodo
	        row.add(null);
	    }
	    
		return true;
    	
    	
    }

    /*
     * Gli indici dei nodi vanno assegnati nell'ordine di inserimento a partire
     * da zero
     */
    @Override
    public boolean addNode(L label) {
        if (label == null) { //controllo che l'etichetta passata non sia nulla
            throw new NullPointerException("L'etichetta passata è nulla");
        }

        
        for (GraphNode<L> existingNode : nodesIndex.keySet()) { // verifico se il nodo con l'etichetta esiste già nel grafo
            if (existingNode.getLabel().equals(label)) {
                return false; 									// Il nodo con l'etichetta è già presente nel grafo
            }
        }
        
        GraphNode<L> newNode = new GraphNode<>(label); // crea un nuovo nodo con l'etichetta fornita
        
        return addNode(newNode); // aggiungi il nodo usando il metodo addNode(GraphNode<L> node) già implementato
    }

    /*
     * Gli indici dei nodi il cui valore sia maggiore dell'indice del nodo da
     * cancellare devono essere decrementati di uno dopo la cancellazione del
     * nodo
     */
    @Override
    public void removeNode(GraphNode<L> node) {
        if(node==null) //controllo il passaggio di elementi nulli
        	throw new NullPointerException("Il nodo passato è nullo");
        if(!nodesIndex.containsKey(node)) //controllo se l'elemento passato è presente
        	throw new IllegalArgumentException("Il nodo passato non è presente");
        
        int indiceNodo = nodesIndex.get(node); //salvo l'indice del nodo passato
        nodesIndex.remove(node); //e lo rimuovo dalla mappa
        
        for(Map.Entry<GraphNode<L>, Integer> element : nodesIndex.entrySet()) { //scorro tutti gli elementi della mappa
        	GraphNode<L> key = element.getKey();
        	int value = element.getValue();
        	if(value>indiceNodo) {	//vedo se l'indice è maggiore di quello rimosso
        		nodesIndex.put(key, getNodeIndexOf(key)-1); //e aggiorno la posizione dell'elemento (per reciclare l'indice dell'elemento rimosso)
        	}
        }
        
        matrix.remove(indiceNodo); //rimuovo il nodo anche dalla matrice
        for(ArrayList<GraphEdge<L>> row : matrix) { //per tutte le righe della matrice elimino l'indice dell'elemento rimosso
        	row.remove(indiceNodo);
        }
    }

    /*
     * Gli indici dei nodi il cui valore sia maggiore dell'indice del nodo da
     * cancellare devono essere decrementati di uno dopo la cancellazione del
     * nodo
     */
    @Override
    public void removeNode(L label) {
        if(label==null) //controllo che l'etichetta passata non sia nulla
        	throw new NullPointerException("L'etichetta passata è nulla");
        if(getNode(label)==null) //controllo che il nodo con quell'etichetta esista
        	throw new IllegalArgumentException("L'etichetta passata non è presente");
        
    	GraphNode<L> node = null; //variabile nodo di appoggio
        
        for (Map.Entry<GraphNode<L>, Integer> element : nodesIndex.entrySet()){ //scorro tutte le chiavi della mappa
    		GraphNode <L> key = element.getKey(); //mi salvo la chiave per il confronto
    		if(key.getLabel()==label) { //confronto l'etichetta della chiave con quella passata
    			node = key;
    			break;
    		}
    	}
        
        if(node==null) //se il nodo è ancora null significa che il nodo non è presente
        	throw new UnsupportedOperationException("Il nodo non esiste");
        
        removeNode(node); //utilizzo il metodo removeNode(GraphNode<L>) già implementato     			
    }

    /*
     * Gli indici dei nodi il cui valore sia maggiore dell'indice del nodo da
     * cancellare devono essere decrementati di uno dopo la cancellazione del
     * nodo
     */
    @Override
    public void removeNode(int i) {
    	if(i<0 || i>this.nodeCount()-1) //controllo che l'indice sia utilizzabile
    		throw new IndexOutOfBoundsException("L'indice passato non è valido");
    	
    	GraphNode<L> node = null; //variabile nodo di appoggio
    	
    	for (Map.Entry<GraphNode<L>, Integer> element : nodesIndex.entrySet()) {//scorro tutte le chiavi della mappa
    		GraphNode<L> key = element.getKey();//mi salvo la chiave per il confronto
    		if(element.getValue()==i) {//confronto l'indice della chiave con quella passata
    			node=key;
    			break;
    		}
    	}
    	
    	removeNode(node); //utilizzo il metodo removeNode(GraphNode<L>) già implementato 
    }

    @Override
    public GraphNode<L> getNode(GraphNode<L> node) {
    	if(node==null) //controllo che il nodo passato non sia nullo
    		throw new NullPointerException("Il nodo passato è nullo");
    	
    	for (Map.Entry<GraphNode<L>, Integer> element : nodesIndex.entrySet()) //scorro tutta la mappa 
    		if (element.getKey().equals(node)) //confronto la chiave con il nodo passato 
                return element.getKey();		//e lo ritorno se questo è identico
    	
    	return null;
    }

    @Override
    public GraphNode<L> getNode(L label) {
    	if(label==null) //controllo che l'etichetta passata non sia nulla
    		throw new NullPointerException("L'etichetta passata è nulla");
    	
    	for (Map.Entry<GraphNode<L>, Integer> element : nodesIndex.entrySet()) //scorro tutta la mappa 
            if (element.getKey().getLabel().equals(label)) //confronto l'etichetta dell'elemento con quella passat
                return element.getKey();					//e ritorno l'elemento (nodo) se questo è identico
        
    	return null;
    }

    @Override
    public GraphNode<L> getNode(int i) {
    	if(i<0 || i>this.nodeCount()-1) //controllo che l'indice passato sia utilizzabile
    		throw new IndexOutOfBoundsException("L'indice passato non è valido");
    	
    	for (Map.Entry<GraphNode<L>, Integer> element : nodesIndex.entrySet()) //scorro la appa
            if (element.getValue()==i) //controllo se l'indice associato all'elemento è quello passato
                return element.getKey(); //se è vero, ritorno il nodo (element)
    	
    	return null;
    }

    @Override
    public int getNodeIndexOf(GraphNode<L> node) {
        if(node==null) //controllo che il nodo passato non sia nullo
        	throw new NullPointerException("Il nodo passato è nullo");
        if(!nodesIndex.containsKey(node)) //controllo che la mappa degli indici contenga il nodo passato (il nodo esiste)
        	throw new IllegalArgumentException("Il nodo non è presente");
        
        int i=0; //variabile di appoggio dell'indice
        for (Map.Entry<GraphNode<L>, Integer> element : nodesIndex.entrySet()) { //scorro la mappa
        	GraphNode<L> key = element.getKey(); //memorizzo il nodo
        	if(key==node) { //se questo corrisponde a quello passato
        		i=element.getValue(); //salvo l'indice e esco dal ciclo
        		break;
        	}
        }
    	return i;
    }

    @Override
    public int getNodeIndexOf(L label) {
        if(label==null) //controllo che l'etichetta passata non sia nlla
        	throw new NullPointerException("L'etichetta passata è nulla");
        if(getNode(label)==null) //controllo che esista un nodo con l'etichetta associata
        	throw new IllegalArgumentException("L'etichetta passata non è presente");
        
        int i=0; //variabile di appoggio dell'indice
        for (Map.Entry<GraphNode<L>, Integer> element : nodesIndex.entrySet()) { //scorro la mappa
        	GraphNode<L> key = element.getKey(); //memorizzo il nodo
        	if(key.getLabel()==label) { //se la sua etichetta corrisponde a quella passata
        		i=element.getValue(); //salvo l'indice e esco dal ciclo
        		break;
        	}
        }
        return i;
    }

    @Override
    public Set<GraphNode<L>> getNodes() {
    	Set<GraphNode<L>> nodesSet = new HashSet<>(); //dichiaro un nuovo set per memorizzare i nodi
    	
    	for (Map.Entry<GraphNode<L>, Integer> element : nodesIndex.entrySet()) { //scorro la mappa
    		GraphNode<L> key = element.getKey(); //memorizzo il nodo 
    		nodesSet.add(key); //lo aggiungo al set
    	}
        
    	return nodesSet; 
    }

    @Override
    public boolean addEdge(GraphEdge<L> edge) {
        if(edge==null)//controllo che l'arco passato non sia nullo
        	throw new NullPointerException("L'arco passato è nullo");
        if(edge.getNode1()==null || edge.getNode2()==null) //controllo che i nodi dell'arco non siano nulli
        	throw new IllegalArgumentException("Uno degli estremi dell'arco è nullo");
        if(isDirected()==true && edge.isDirected()==false) //controllo che l'arco non sia orientato su un grafo non orientato (e viceversa sotto)
        	throw new IllegalArgumentException("Grafo orientato, non puoi mettere un arco non orientato");
        if(isDirected()==false && edge.isDirected()==true) 
        	throw new IllegalArgumentException("Grafo orientato, non puoi mettere un arco non orientato");
        
        for(ArrayList<GraphEdge<L>> row : matrix) //scorro la matrice e controllo se l'arco c'è già (non faccio nulla)
        	if(row.contains(edge))
        		return false;
        
        GraphNode<L> node1 = edge.getNode1(); // salvo il nodo1 e nodo2 dell'arco
        GraphNode<L> node2 = edge.getNode2();
        ArrayList<GraphEdge<L>> edgeArray = new ArrayList<>(); //creo una nuova lista di archi per il nuovo arco
        
        edgeArray=matrix.get(getNodeIndexOf(node1)); //lista di adiacenza del nodo 1
        edgeArray.set(getNodeIndexOf(node2), edge); //imposto l'edge passato tra nodo 1 e nodo 2 nella matrice
        matrix.set(getNodeIndexOf(node1), edgeArray); //aggiorno la riga del nodo1 con la lista di adiacenza corretta
        
        if(!edge.isDirected()){ //se non è orientato faccio lo stesso simmetricamente
            edgeArray=matrix.get(getNodeIndexOf(node2));
            edgeArray.set(getNodeIndexOf(node1), edge);
            matrix.set(getNodeIndexOf(node2),edgeArray);
        }
        
        return true;
    }

    @Override
    public boolean addEdge(GraphNode<L> node1, GraphNode<L> node2) {
        if(node1==null || node2==null) //controllo che i nodi passati non siano nulli
        	throw new NullPointerException("Almeno uno dei due nodi è nullo");
        if(!nodesIndex.containsKey(node1) || !nodesIndex.containsKey(node2)) //controlli che la mappa contenga i nodi passati
        	throw new IllegalArgumentException("Almeno uno dei due nodi non è presente nel grafo");
        
        GraphEdge<L> newEdge = new GraphEdge<>(node1, node2, isDirected()); //creo il nuovo arco con i due nodi
        for(ArrayList<GraphEdge<L>> row : matrix)//scorro la matrice e controllo se l'arco c'è già (non faccio nulla)
        	if(row.contains(newEdge))
        		return false;
        
        return addEdge(newEdge); //aggiungo il nuovo arco sfruttando il metodo addEdge(GraphEdge<L>) implementato sopra
    }

    @Override
    public boolean addWeightedEdge(GraphNode<L> node1, GraphNode<L> node2,
            double weight) {
        if(node1==null || node2==null) //controllo che i nodi passati non siano nulli
        	throw new NullPointerException("Almeno uno dei due nodi è nullo");
        if(!nodesIndex.containsKey(node1) || !nodesIndex.containsKey(node2)) //controllo che la mappa contenga i nodi passati
        	throw new IllegalArgumentException("Almeno uno dei due nodi non è presente nel grafo");
        
        GraphEdge<L> newEdge = new GraphEdge<>(node1, node2, isDirected(), weight); //creo un nuovo nodo con il peso
        for(ArrayList<GraphEdge<L>> row : matrix) //scorro la matrice e controllo se l'arco c'è già (non faccio nulla)
        	if(row.contains(newEdge))
        		return false;
        
        return addEdge(newEdge); //aggiungo il nuovo arco sfruttando il metodo addEdge(GraphEdge<L>) implementato sopra
    }

    @Override
    public boolean addEdge(L label1, L label2) {
        if(label1==null || label2 == null) //controllo che le etichette passate non siano nulle
        	throw new NullPointerException("Almeno una delle due etichette è nulla");
        if(!nodesIndex.containsKey(getNode(label1)) || !nodesIndex.containsKey(getNode(label2))) //controllo che esistano nodi con le etichette passate
        	throw new IllegalArgumentException("Almeno una delle due etichette non è presente");
        
        GraphEdge<L> newEdge = new GraphEdge<>(getNode(label1), getNode(label2), isDirected()); //creo un arco con i nodi delle etichette 
        for(ArrayList<GraphEdge<L>> row : matrix) //scorro la matrice e controllo se l'arco c'è già (non faccio nulla)
        	if(row.contains(newEdge))
        		return false;
        
        return addEdge(newEdge); //aggiungo il nuovo arco sfruttando il metodo addEdge(GraphEdge<L>) implementato sopra
    }

    @Override
    public boolean addWeightedEdge(L label1, L label2, double weight) {
        if(label1==null || label2 == null) //controllo che le etichette passate non siano nulle
        	throw new NullPointerException("Almeno una delle due etichette è nulla");
        if(!nodesIndex.containsKey(getNode(label1)) || !nodesIndex.containsKey(getNode(label2))) //controllo che esistano nodi con le etichette passate
        	throw new IllegalArgumentException("Almeno una delle due etichette non è presente");
        
        GraphEdge<L> newEdge = new GraphEdge<>(getNode(label1), getNode(label2), isDirected(), weight);//creo un nuovo nodo con il peso
        for(ArrayList<GraphEdge<L>> row : matrix) //scorro la matrice e controllo se l'arco c'è già (non faccio nulla)
        	if(row.contains(newEdge))
        		return false;
        
        return addEdge(newEdge); //aggiungo il nuovo arco sfruttando il metodo addEdge(GraphEdge<L>) implementato sopra
    }

    @Override
    public boolean addEdge(int i, int j) {
    	if((i<0 || i>this.nodeCount()-1) || (j<0 || j>this.nodeCount()-1)) //controllo che gli indici passati siano utilizzabili
    		throw new IndexOutOfBoundsException("Gli indici passati non sono validi");
        if(!nodesIndex.containsKey(getNode(i)) || !nodesIndex.containsKey(getNode(j)))
        	throw new IllegalArgumentException("Almeno una delle due etichette non è presente"); //controllo che esistano nodi con quei indici
        
        GraphEdge<L> newEdge = new GraphEdge<>(getNode(i), getNode(j), isDirected()); //creo un nuodo con i suddetti nodi
        for(ArrayList<GraphEdge<L>> row : matrix) //scorro la matrice e controllo se l'arco c'è già (non faccio nulla)
        	if(row.contains(newEdge))
        		return false;
        
        return addEdge(newEdge); //aggiungo il nuovo arco sfruttando il metodo addEdge(GraphEdge<L>) implementato sopra
    }

    @Override
    public boolean addWeightedEdge(int i, int j, double weight) {
    	if((i<0 || i>this.nodeCount()-1) || (j<0 || j>this.nodeCount()-1)) //controllo che gli indici passati siano utilizzabili
    		throw new IndexOutOfBoundsException("Gli indici passati non sono validi");
        if(!nodesIndex.containsKey(getNode(i)) || !nodesIndex.containsKey(getNode(j))) //controllo che esistano nodi con quei indici
        	throw new IllegalArgumentException("Almeno una delle due etichette non è presente");
        
        GraphEdge<L> newEdge = new GraphEdge<>(getNode(i), getNode(j), isDirected(), weight); //creo un nodo con anche il peso
        for(ArrayList<GraphEdge<L>> row : matrix) //scorro la matrice e controllo se l'arco c'è già (non faccio nulla)
        	if(row.contains(newEdge))
        		return false;
        
        return addEdge(newEdge); //aggiungo il nuovo arco sfruttando il metodo addEdge(GraphEdge<L>) implementato sopra
    }

    @Override
    public void removeEdge(GraphEdge<L> edge) {
    	if(edge==null) //controllo che l'arco passato non sia nullo
    		throw new NullPointerException("L'arco passato è nullo");
    	if(nodesIndex.get(edge.getNode1())==null || nodesIndex.get(edge.getNode2())==null) //controllo che i nodi dell'arco siano presenti
        	throw new IllegalArgumentException("Almeno uno dei due nodi dell'arco non è presente");
    	
    	GraphNode<L> node1 = edge.getNode1(); //mi salvo i due nodi dell'arco
    	GraphNode<L> node2 = edge.getNode2();
    	
    	if(matrix.get(nodesIndex.get(node1)).get(nodesIndex.get(node2))== null //controllo l'esistenza 
    			|| !matrix.get(nodesIndex.get(node1)).get(nodesIndex.get(node2)).equals(edge))
    		throw new IllegalArgumentException("Il nodo non esiste");
    	
    	matrix.get(nodesIndex.get(node1)).set(nodesIndex.get(node2), null); //in riga e colonna setto il null per rimuovere l'arco
    	matrix.get(nodesIndex.get(node2)).set(nodesIndex.get(node1), null);
    }

    @Override
    public void removeEdge(GraphNode<L> node1, GraphNode<L> node2) {
        if(node1==null || node2==null)//controllo che i nodi passati non siano nulli
        	throw new NullPointerException("Almeno uno dei due nodi è nullo");
        
        GraphEdge<L> node = new GraphEdge<L>(node1, node2, isDirected()); //creo un nuovo edge con i nodi passati
        
        removeEdge(node); //lo rimuovo utilizzando il metodo removeEdge(GraphEdge<L>) implementato precedentemente
        
    }

    @Override
    public void removeEdge(L label1, L label2) {
    	if(label1==null || label2 == null) //controllo che le etichette passate non siano nulle
        	throw new NullPointerException("Almeno una delle due etichette è nulla");
        if(!nodesIndex.containsKey(getNode(label1)) || !nodesIndex.containsKey(getNode(label2))) //controllo che esistano nodi con l'etichetta
        	throw new IllegalArgumentException("Almeno una delle due etichette non è presente");
        
        GraphNode<L> node1 = new GraphNode<>(label1); //creo i nodi con le etichette passate
        GraphNode<L> node2 = new GraphNode<>(label2);
        
        removeEdge(node1,node2); //lo rimuovo utilizzando il metodo removeEdge(GraphEdge<L>) implementato precedentemente
    }

    @Override
    public void removeEdge(int i, int j) {
    	if((i<0 || i>this.nodeCount()-1) || (j<0 || j>this.nodeCount()-1)) //controllo che gli indici passati siano validi
    		throw new IndexOutOfBoundsException("Gli indici passati non sono validi");
        if(!nodesIndex.containsKey(getNode(i)) || !nodesIndex.containsKey(getNode(j))) //controllo che esistano nodi associati agli indici
        	throw new IllegalArgumentException("Almeno una delle due etichette non è presente");
        
        GraphNode<L> node1 = null; //istanzio due varibili per memorizzare i nodi
        GraphNode<L> node2= null;
        
        for (GraphNode<L> key : this.nodesIndex.keySet()) { //scorro la mappa per cerca i nodi dei rispettivi indici
        	if(nodesIndex.get(key)==i)
        		node1 = key;
        	if(nodesIndex.get(key)==j)
        		node2 = key;
        }
        
        removeEdge(node1,node2); //lo rimuovo utilizzando il metodo removeEdge(GraphEdge<L>) implementato precedentemente
    }
    
    @Override
    public GraphEdge<L> getEdge(GraphEdge<L> edge) {
        if(edge== null)
        	throw new NullPointerException("L'arco passato è nullo"); //controllo che l'arco passato non sia nullo
        if(!nodesIndex.containsKey(edge.getNode1()) || !nodesIndex.containsKey(edge.getNode2()))
            throw new IllegalArgumentException("Almeno uno dei due nodi dell'arco non esiste"); //controllo che entrambi i nodi esistano

        GraphEdge<L> returnedEdge= null; //variabile di appoggio per l'arco da ritornare
        
        for(ArrayList<GraphEdge<L>> riga : matrix) //scorro le rigaìhe della matrice
            for (GraphEdge<L> elemento : riga) //scorro gli elementi della riga
            if(elemento!= null && elemento.equals(edge)) //controllo se questo non è nullo e corrisponde a quello passato
            	returnedEdge=edge;
           
        return returnedEdge;
    }

    @Override
    public GraphEdge<L> getEdge(GraphNode<L> node1, GraphNode<L> node2) {
        if(node1==null || node2==null) //controllo che i nodi passati non siano nulli
        	throw new NullPointerException("Almeno uno dei due nodi è nullo");
        if(!nodesIndex.containsKey(node1) || !nodesIndex.containsKey(node2))
        	throw new IllegalArgumentException("Almeno uno dei due nodi  è nullo"); //controllo che esistano i due nodi
        
        GraphEdge<L> newEdge= new GraphEdge<>(node1,node2,isDirected()); //creo un nuovo arco con i nodi passati
        
        return getEdge(newEdge); //ritorno l'arco utilizzando il getEdge(GraphEdge<L> edge) implementato sopra
    }

    @Override
    public GraphEdge<L> getEdge(L label1, L label2) {
        if(label1==null || label2 == null) //controllo che le etichette passate non siano nulle
        	throw new NullPointerException("Almeno una delle due etichette è nulla");
        if(getNode(label1)==null || getNode(label2)==null) //controllo che esistano nodi con le etichette associate
        	throw new IllegalArgumentException("Almeno una delle due etichette non è presente");
        
        //cero cercando i nodi nella matrice sfruttando gli indici dei nodi associati alle etichette passate
        GraphEdge<L> returnedEdge = matrix.get(getNodeIndexOf(label1)).get(getNodeIndexOf(label2)); 
        
        return returnedEdge;
    }

    @Override
    public GraphEdge<L> getEdge(int i, int j) {
    	if((i<0 || i>this.nodeCount()-1) || (j<0 || j>this.nodeCount()-1)) //controllo che gli indici siano validi
    		throw new IndexOutOfBoundsException("Gli indici passati non sono validi");
    	
    	//ritorno l'arco utilizzando il getEdge(GraphNode<L> node1, GraphNode<L> node2) implementato sopra
        return getEdge(getNode(i), getNode(j)); 
    }

    @Override
    public Set<GraphNode<L>> getAdjacentNodesOf(GraphNode<L> node) {
    	if(node==null) //controllo che il nodo passato non sia nullo
        	throw new NullPointerException("Il nodo passato è nullo");
        if(!nodesIndex.containsKey(node)) //controllo che il nodo esista
        	throw new IllegalArgumentException("Il nodo non è presente");
        
        Set<GraphNode<L>> AdjacentNodesSet = new HashSet<>(); //istanzio un nuvo set da restituire dove memorizzo i nodi adiacenti
        
        for(ArrayList<GraphEdge<L>> row : matrix) //scorro le righe della matrice fino a trovare quella del nodo passato (tramite indice)
        	if(matrix.indexOf(row)==getNodeIndexOf(node)) 
        		for(GraphEdge<L> element : row) { //scorro tutti gli elementi dell riga 
        			if(element != null && element.getNode1().equals(node)) //memorizzo i nodi adiacenti
        				AdjacentNodesSet.add(element.getNode2());
        			if(element != null && element.getNode2().equals(node))
        				AdjacentNodesSet.add(element.getNode1());
        		}
        
        return AdjacentNodesSet;
    }

    @Override
    public Set<GraphNode<L>> getAdjacentNodesOf(L label) {
    	if(label==null) //controllo che l'etichetta non sia nulla
    		throw new NullPointerException("L'etichetta passata è nulla");
        if(!nodesIndex.containsKey(getNode(label))) //controllo che esista un nodo associato all'etichetta
         	throw new IllegalArgumentException("L'etichetta passata non è presente");
        
        GraphNode<L> node = getNode(label); //creo un nuovo nodo dove memorizzare quello associato all'etichetta
        
        return getAdjacentNodesOf(node); //ritorno gli adiacenti sfruttando il metodo getAdjacentNodesOf(GraphNode<L> node) implementato sopra
    }

    @Override
    public Set<GraphNode<L>> getAdjacentNodesOf(int i) {
    	if(i<0 || i>this.nodeCount()-1) //controllo che l'indice passato sia valido
    		throw new IndexOutOfBoundsException("L'indice passato non è valido");
    	
    	GraphNode<L> node = getNode(i);// nuovo nodo dove memorizzare quello associato all'indice
    	
    	//ritorno gli adiacenti sfruttando il metodo getAdjacentNodesOf(GraphNode<L> node) implementato precedentemente
    	return getAdjacentNodesOf(node); 
    }

    @Override
    public Set<GraphNode<L>> getPredecessorNodesOf(GraphNode<L> node) {
        throw new UnsupportedOperationException(
                "Operazione non supportata in un grafo non orientato");
    }

    @Override
    public Set<GraphNode<L>> getPredecessorNodesOf(L label) {
        throw new UnsupportedOperationException(
                "Operazione non supportata in un grafo non orientato");
    }

    @Override
    public Set<GraphNode<L>> getPredecessorNodesOf(int i) {
        throw new UnsupportedOperationException(
                "Operazione non supportata in un grafo non orientato");
    }

    @Override
    public Set<GraphEdge<L>> getEdgesOf(GraphNode<L> node) {
    	if(node==null) //controllo che il nodo passato non sia nullo
        	throw new NullPointerException("Il nodo passato è nullo");
        if(!nodesIndex.containsKey(node)) //controllo che ci sia un'indice associato al nodo (il nodo esiste)
        	throw new IllegalArgumentException("Il nodo non è presente");
        
        Set<GraphEdge<L>> edgesSet = new HashSet<>(); //creo un set da ritorndare dove memorizzare gli archi
        
        for(ArrayList<GraphEdge<L>> row : matrix) { //scorro le righe della matrice fino a trovare quella del nodo passato (tramite indice)
        	if(matrix.indexOf(row)==getNodeIndexOf(node)) 
        		for(GraphEdge<L> element : row) //scorro gli elementi della riga 
        			if(element != null) 
        				edgesSet.add(element); //se l'elemento non è nullo (c'è l'arco) lo aggiungo al set
        }
        
        return edgesSet;
    }

    @Override
    public Set<GraphEdge<L>> getEdgesOf(L label) {
    	if(label==null) //controllo che l'etichetta passata non sia nulla
        	throw new NullPointerException("L'etichetta passata è nulla");
        if(!nodesIndex.containsKey(getNode(label))) //controllo che esista un nodo associato all'etichetta
        	throw new IllegalArgumentException("Il nodo non è presente");
        
        GraphNode<L> node = getNode(label); //creo un nodo dove salvo quello associato all'etichetta
        
        return getEdgesOf(node); //ritorno il set tramitre il metodo getEdgesOf(GraphNode<L>) implementato sopra
    }

    @Override
    public Set<GraphEdge<L>> getEdgesOf(int i) {
    	if(i<0 || i>this.nodeCount()-1) //controllo che l'indice passato sia un indice valido
    		throw new IndexOutOfBoundsException("L'indice passato non è valido");
    	
    	GraphNode<L> newNode = getNode(i); //creo un nuovo nodo dove memorizzo quello associato all'indice i
    	
    	return getEdgesOf(newNode); //ritorno il set tramitre il metodo getEdgesOf(GraphNode<L>) implementato precedentemente
    }

    @Override
    public Set<GraphEdge<L>> getIngoingEdgesOf(GraphNode<L> node) {
        throw new UnsupportedOperationException(
                "Operazione non supportata in un grafo non orientato");
    }

    @Override
    public Set<GraphEdge<L>> getIngoingEdgesOf(L label) {
        throw new UnsupportedOperationException(
                "Operazione non supportata in un grafo non orientato");
    }

    @Override
    public Set<GraphEdge<L>> getIngoingEdgesOf(int i) {
        throw new UnsupportedOperationException(
                "Operazione non supportata in un grafo non orientato");
    }

    @Override
    public Set<GraphEdge<L>> getEdges() {
    	Set<GraphEdge<L>> edgesSet = new HashSet<>(); //creo un set dove salvare gli archi del grafo
    	
    	for (ArrayList<GraphEdge<L>> row : matrix) //scorro tutte le righe
    		for(GraphEdge<L> element : row) //scorro tutti gli elementi della riga
    			if(element != null) 
    				edgesSet.add(element); //se l'elemento è nullo lo aggiungo al set
        
    	return edgesSet;
    }
}
