package it.unicam.cs.asdl2324.mp2;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

//ATTENZIONE: è vietato includere import a pacchetti che non siano della Java SE

/**
 * Implementazione dell'interfaccia <code>DisjointSets<E></code> tramite una
 * foresta di alberi ognuno dei quali rappresenta un insieme disgiunto. Si
 * vedano le istruzioni o il libro di testo Cormen et al. (terza edizione)
 * Capitolo 21 Sezione 3.
 * 
 * @author Luca Tesei (template) Tommaso, Cosci, tommaso.cosci@studenti.unicam.it (implementazione)
 *
 * @param <E>
 *                il tipo degli elementi degli insiemi disgiunti
 */
public class ForestDisjointSets<E> implements DisjointSets<E> {

    /*
     * Mappa che associa ad ogni elemento inserito il corrispondente nodo di un
     * albero della foresta. La variabile è protected unicamente per permettere
     * i test JUnit.
     */
    protected Map<E, Node<E>> currentElements;
    
    /*
     * Classe interna statica che rappresenta i nodi degli alberi della foresta.
     * Gli specificatori sono tutti protected unicamente per permettere i test
     * JUnit.
     */
    protected static class Node<E> {
        /*
         * L'elemento associato a questo nodo
         */
        protected E item;

        /*
         * Il parent di questo nodo nell'albero corrispondente. Nel caso in cui
         * il nodo sia la radice allora questo puntatore punta al nodo stesso.
         */
        protected Node<E> parent;

        /*
         * Il rango del nodo definito come limite superiore all'altezza del
         * (sotto)albero di cui questo nodo è radice.
         */
        protected int rank;

        /**
         * Costruisce un nodo radice con parent che punta a se stesso e rango
         * zero.
         * 
         * @param item
         *                 l'elemento conservato in questo nodo
         * 
         */
        public Node(E item) {
            this.item = item;
            this.parent = this;
            this.rank = 0;
        }

    }

    /**
     * Costruisce una foresta vuota di insiemi disgiunti rappresentati da
     * alberi.
     */
    public ForestDisjointSets() {
    	this.currentElements = new HashMap<E, Node<E>>();
    }

    @Override
    public boolean isPresent(E e) {
    	if(e==null) //controllo che l'elemento non sia nullo
    		throw new NullPointerException("L'elemento passato è nullo");
    	
    	if(currentElements.containsKey(e)) //controllo se l'elemento è contenuto nella mappa
    		return true;
    	else
    		return false;
    }

    /*
     * Crea un albero della foresta consistente di un solo nodo di rango zero il
     * cui parent è se stesso.
     */
    @Override
    public void makeSet(E e) {
    	if(e==null) //controllo che l'elemento passato non sia nullo
    		throw new NullPointerException("L'elemento passato è nullo");
    	if(isPresent(e)) //controllo che l'elemento passato sia presente
    		throw new IllegalArgumentException("L'elemento è già presente");
    	
    	Node<E> newNode = new Node<E>(e); //creo un nuovo nodo con l'elemento passato
    	currentElements.put(e, newNode); //lo aggiungo alla mappa
    }

    /*
     * L'implementazione del find-set deve realizzare l'euristica
     * "compressione del cammino". Si vedano le istruzioni o il libro di testo
     * Cormen et al. (terza edizione) Capitolo 21 Sezione 3.
     */
    @Override
    public E findSet(E e) {
    	if(e==null)
    		throw new NullPointerException("L'elemento passato è nullo");
    	if(!isPresent(e))
    		return null;

        Node<E> currentNode = currentElements.get(e); //salvo il nodo legato all'elemento passato
    
        if(currentNode.item!=currentNode.parent.item) { //controllo se il parent è se stesso (quindi non entro e ritorno il parent)
        	E newParent = findSet(currentNode.parent.item);  //richiamo ricorsivamente fino a trovare il padre del set
        	currentNode.parent = currentElements.get(newParent); //aggiorno il parent da ritornare 
        }
        
        return currentNode.parent.item;
    }

    /*
     * L'implementazione dell'unione deve realizzare l'euristica
     * "unione per rango". Si vedano le istruzioni o il libro di testo Cormen et
     * al. (terza edizione) Capitolo 21 Sezione 3. In particolare, il
     * rappresentante dell'unione dovrà essere il rappresentante dell'insieme il
     * cui corrispondente albero ha radice con rango più alto. Nel caso in cui
     * il rango della radice dell'albero di cui fa parte e1 sia uguale al rango
     * della radice dell'albero di cui fa parte e2 il rappresentante dell'unione
     * sarà il rappresentante dell'insieme di cui fa parte e2.
     */
    @Override
    public void union(E e1, E e2) {
        if (e1 == null || e2 == null) //controllo che gli elementi passati non siano nulli
            throw new NullPointerException("Almeno uno dei due elementi è nullo");
        if (!isPresent(e1) || !isPresent(e2)) //controllo che gli elementi siano presenti
            throw new IllegalArgumentException("Alemno uno dei due elementi non è presente");
        
        Node<E> parent1 = currentElements.get(e1).parent; //salvo in una variabile i parent dei due elementi
        Node<E> parent2 = currentElements.get(e2).parent;
        
        if(parent1 != parent2) //confronto i parent in modo che faccio operazioni solo se effettivamente i due elementi sono "distinti"
        	if(parent1.rank>parent2.rank) //confronto i rank per come fare l'unione
        		parent2.parent=parent1; //reimposto il parent del "più piccolo"
        	else {
        		if(parent1.rank==parent2.rank) //confronto il rank se uguale
        			parent2.rank++;				//lo aumento di uno per l'unione
        		
        		parent1.parent=parent2; //reimposto il parent del "più piccolo"
        	}
        	
        
    }

    @Override
    public Set<E> getCurrentRepresentatives() {
    	Set<E> currentRapp = new HashSet<>(); //dichiaro un nuovo set per contenere i rapp
    	
    	for(E element : currentElements.keySet()) //scorro tutte gli elementi del set e memorizzo nel set i rispettivi rapp
    		currentRapp.add(findSet(element));		//senza pensare ai duplicati poiché l'hashset non li ammette
    	
    	return currentRapp;
    }

    @Override
    public Set<E> getCurrentElementsOfSetContaining(E e) {
    	if(e==null) //controllo che l'elemento non sia nullo
    		throw new NullPointerException("L'elemento passato è nullo");
    	if(!isPresent(e)) //controllo che l'elemento sia presente nella mappa
    		throw new IllegalArgumentException("L'elemento passato non è presente");

    	Set<E> currents = new HashSet<>(); //dichiaro un nuovo set per contenere gli elementi
    	E parent = findSet(e);
    	
    	for(E element : currentElements.keySet()) //scorro gli elementi della mappa 
    		if(currentElements.get(element).parent.item == parent) //se il loro parent è identico a quello di riferimeto
    			currents.add(element);	//li aggiungo al set
    	
    	return currents;
    }

    @Override
    public void clear() {
    	currentElements = new HashMap<E, Node<E>>(); //per pulire la mappa semplicemente ne creo una nuova
    }

}
