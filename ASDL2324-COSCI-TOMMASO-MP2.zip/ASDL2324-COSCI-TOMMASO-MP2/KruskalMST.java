package it.unicam.cs.asdl2324.mp2;

import java.util.*;

//ATTENZIONE: è vietato includere import a pacchetti che non siano della Java SE

/**
 * 
 * Classe singoletto che implementa l'algoritmo di Kruskal per trovare un
 * Minimum Spanning Tree di un grafo non orientato, pesato e con pesi non
 * negativi. L'algoritmo implementato si avvale della classe
 * {@code ForestDisjointSets<GraphNode<L>>} per gestire una collezione di
 * insiemi disgiunti di nodi del grafo.
 * 
 * @author Luca Tesei (template) **Tommaso, Cosci, tommaso.cosci@studenti.unicam.it (implementazione)
 * 
 * @param <L>
 *                tipo delle etichette dei nodi del grafo
 *
 */
public class KruskalMST<L> {

    /*
     * Struttura dati per rappresentare gli insiemi disgiunti utilizzata
     * dall'algoritmo di Kruskal.
     */
    private ForestDisjointSets<GraphNode<L>> disjointSets;

    /**
     * Costruisce un calcolatore di un albero di copertura minimo che usa
     * l'algoritmo di Kruskal su un grafo non orientato e pesato.
     */
    public KruskalMST() {
        this.disjointSets = new ForestDisjointSets<GraphNode<L>>();
    }

    /**
     * Utilizza l'algoritmo goloso di Kruskal per trovare un albero di copertura
     * minimo in un grafo non orientato e pesato, con pesi degli archi non
     * negativi. L'albero restituito non è radicato, quindi è rappresentato
     * semplicemente con un sottoinsieme degli archi del grafo.
     * 
     * @param g
     *              un grafo non orientato, pesato, con pesi non negativi
     * @return l'insieme degli archi del grafo g che costituiscono l'albero di
     *         copertura minimo trovato
     * @throw NullPointerException se il grafo g è null
     * @throw IllegalArgumentException se il grafo g è orientato, non pesato o
     *        con pesi negativi
     */
    public Set<GraphEdge<L>> computeMSP(Graph<L> g) {
    	if(g==null) //controllo che il grafo passato non sia nullo
    		throw new NullPointerException("Il grafo passato è nullo");
    	if(g.isDirected()) //controllo che sia orientato
    		throw new IllegalArgumentException("Il grafo è orientato: impossibile utilizzare l'algoritmo");
    	
    	disjointSets.clear(); //pulisco il set
    	Set<GraphEdge<L>> edgesSet = new HashSet<>(); //salvo in un set gli archi del grafo g
    	
        for (GraphNode<L> node : g.getNodes()) //faccio il makeSet() di ogni nodo 
            disjointSets.makeSet(node);
       
        //creo una nuova lista con tutti gli archi
        ArrayList<GraphEdge<L>> edgesList = new ArrayList<>(g.getEdges()); //creo una nuova lista cone 
        
        sort(edgesList); //riordino la lista attrvaerso un metodo che implementa il bubble-sort
    	
    	for(GraphEdge<L> edge : edgesList) { //scorro tutta la lista
    		if(edge.getWeight()<0 || !edge.hasWeight()) //controllo pesi negativi e/o nulli
    			throw new IllegalArgumentException("Gli archi hanno pesi negativi e/o non sono pesati");
    		if(disjointSets.findSet(edge.getNode1())!= disjointSets.findSet(edge.getNode2())){ //controllo 
    			edgesSet.add(edge); //aggiungol'arco al set da ritornare
    			disjointSets.union(edge.getNode1(),edge.getNode2()); //unisco i due nodi (con i rispettivi pesi)
    		}
    	
    	}		
    			
        return edgesSet;
    }
    
    /**
     * Implementazione dell'algoritmo di bubble-sort per l'ordinamento di una lista
     * composto da archi del tipo GraphEdge<L>.
     * 
     * @param list
     * 				una lista di oggetti GraphEdge<L>
     */
    
    public void sort(List<GraphEdge<L>> list) {
    	boolean changed;
    	int length = list.size();
    	
    	do {
    		changed=false;
    		for(int i=1; i<length;i++)
                if (list.get(i - 1).getWeight() > list.get(i).getWeight()) {
                    GraphEdge<L> temp = list.get(i - 1);
                    list.set(i - 1, list.get(i));
                    list.set(i, temp);
    				
    				changed=true;
    			}
    	length--;	
    	
    	}while(changed);
    }
    
}
